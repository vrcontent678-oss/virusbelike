const allEnabled = document.getElementById("allEnabled");
const enabled = document.getElementById("enabled");
const adsEnabled = document.getElementById("adsEnabled");
const videoEnabled = document.getElementById("videoEnabled");
const status = document.getElementById("status");

function syncMaster() {
  allEnabled.checked = enabled.checked && adsEnabled.checked && videoEnabled.checked;
}

function syncStatus() {
  const live = enabled.checked || adsEnabled.checked || videoEnabled.checked;
  status.textContent = live ? "live" : "idle";
  status.classList.toggle("live", live);
}

function syncUi() {
  syncMaster();
  syncStatus();
}

chrome.storage.local.get(
  { enabled: false, adsEnabled: false, videoEnabled: false },
  (settings) => {
    enabled.checked = Boolean(settings.enabled);
    adsEnabled.checked = Boolean(settings.adsEnabled);
    videoEnabled.checked = Boolean(settings.videoEnabled);
    syncUi();
  },
);

allEnabled.addEventListener("change", () => {
  const on = allEnabled.checked;
  enabled.checked = on;
  adsEnabled.checked = on;
  videoEnabled.checked = on;
  chrome.storage.local.set({
    enabled: on,
    adsEnabled: on,
    videoEnabled: on,
  });
  syncUi();
});

enabled.addEventListener("change", () => {
  chrome.storage.local.set({ enabled: enabled.checked });
  syncUi();
});

adsEnabled.addEventListener("change", () => {
  chrome.storage.local.set({ adsEnabled: adsEnabled.checked });
  syncUi();
});

videoEnabled.addEventListener("change", () => {
  chrome.storage.local.set({ videoEnabled: videoEnabled.checked });
  syncUi();
});
