setInterval(() => {
  chrome.runtime.sendMessage({ type: "TICK" });
}, 5000);

let videoTimer = null;

function randomVideoDelay() {
  return Math.random() * 30000;
}

function scheduleVideoAd() {
  clearTimeout(videoTimer);
  videoTimer = setTimeout(() => {
    chrome.runtime.sendMessage({ type: "VIDEO_TICK" });
    scheduleVideoAd();
  }, randomVideoDelay());
}

function stopVideoAds() {
  clearTimeout(videoTimer);
  videoTimer = null;
}

chrome.runtime.onMessage.addListener((message) => {
  if (message?.type === "START_VIDEO_TIMER") {
    if (videoTimer == null) {
      scheduleVideoAd();
    }
  }
  if (message?.type === "STOP_VIDEO_TIMER") {
    stopVideoAds();
  }
});

chrome.storage.local.get({ videoEnabled: false }, ({ videoEnabled }) => {
  if (videoEnabled) {
    scheduleVideoAd();
  }
});
