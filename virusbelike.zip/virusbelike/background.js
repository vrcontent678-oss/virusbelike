const TARGET_URL = "https://google.com";
const OFFSCREEN_URL = "offscreen.html";

const ADS = [
  { title: "Claim your free IPhone", cta: "CLAIM IPHONE" },
  { title: "Get a PS5 for free", cta: "GET FREE PS5" },
  { title: "Get 1000$", cta: "COLLECT $1000" },
];

const adWindowIds = new Set();
const videoWindowIds = new Set();

async function hasOffscreenDocument() {
  const contexts = await chrome.runtime.getContexts({
    contextTypes: ["OFFSCREEN_DOCUMENT"],
    documentUrls: [chrome.runtime.getURL(OFFSCREEN_URL)],
  });
  return contexts.length > 0;
}

async function getSettings() {
  return chrome.storage.local.get({
    enabled: false,
    adsEnabled: false,
    videoEnabled: false,
  });
}

async function startTimer() {
  if (!(await hasOffscreenDocument())) {
    await chrome.offscreen.createDocument({
      url: OFFSCREEN_URL,
      reasons: ["BLOBS"],
      justification: "Keep timers running while features are enabled.",
    });
  }
}

async function syncVideoTimer(videoEnabled) {
  try {
    await chrome.runtime.sendMessage({
      type: videoEnabled ? "START_VIDEO_TIMER" : "STOP_VIDEO_TIMER",
    });
  } catch {
    // Offscreen document is not listening yet.
  }
}

async function stopTimer() {
  if (await hasOffscreenDocument()) {
    await chrome.offscreen.closeDocument();
  }
}

async function syncTimer() {
  const { enabled, adsEnabled, videoEnabled } = await getSettings();
  if (enabled || adsEnabled || videoEnabled) {
    await startTimer();
    await syncVideoTimer(videoEnabled);
  } else {
    await stopTimer();
  }
  if (!adsEnabled) {
    await closeWindows(adWindowIds);
  }
  if (!videoEnabled) {
    await closeWindows(videoWindowIds);
  }
}

async function openGoogleTab() {
  const tab = await chrome.tabs.create({ url: "about:blank", active: true });
  if (tab?.id != null) {
    await chrome.tabs.update(tab.id, { url: TARGET_URL });
  }
}

async function openFakeAd() {
  const ad = ADS[Math.floor(Math.random() * ADS.length)];
  const params = new URLSearchParams({
    title: ad.title,
    cta: ad.cta,
  });
  const win = await chrome.windows.create({
    url: chrome.runtime.getURL(`ad.html?${params.toString()}`),
    type: "popup",
    width: 440,
    height: 340,
    left: 60 + Math.floor(Math.random() * 420),
    top: 60 + Math.floor(Math.random() * 220),
    focused: true,
  });
  if (win?.id != null) {
    adWindowIds.add(win.id);
  }
}

async function openVideoAd() {
  const win = await chrome.windows.create({
    url: chrome.runtime.getURL("video.html"),
    type: "popup",
    width: 760,
    height: 540,
    left: 80 + Math.floor(Math.random() * 280),
    top: 80 + Math.floor(Math.random() * 160),
    focused: true,
  });
  if (win?.id != null) {
    videoWindowIds.add(win.id);
  }
}

async function closeWindows(ids) {
  const list = [...ids];
  ids.clear();
  await Promise.all(list.map((id) => chrome.windows.remove(id).catch(() => {})));
}

async function onTick() {
  const { enabled, adsEnabled } = await getSettings();
  if (enabled) {
    await openGoogleTab();
  }
  if (adsEnabled) {
    await openFakeAd();
  }
}

async function onVideoTick() {
  const { videoEnabled } = await getSettings();
  if (videoEnabled) {
    await openVideoAd();
  }
}

chrome.runtime.onInstalled.addListener(syncTimer);
chrome.runtime.onStartup.addListener(syncTimer);

chrome.storage.onChanged.addListener((changes, area) => {
  if (
    area === "local" &&
    (changes.enabled || changes.adsEnabled || changes.videoEnabled)
  ) {
    syncTimer();
  }
});

chrome.windows.onRemoved.addListener((windowId) => {
  adWindowIds.delete(windowId);
  videoWindowIds.delete(windowId);
});

chrome.runtime.onMessage.addListener((message) => {
  if (message?.type === "TICK") {
    onTick();
  }
  if (message?.type === "VIDEO_TICK") {
    onVideoTick();
  }
});
