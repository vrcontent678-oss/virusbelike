const WHOPPER_URL =
  "https://www.burger-king.ch/de/menu/picker-a28b8b31-e5c2-4344-913f-82194d4b0c99";

const video = document.getElementById("ad");
const muteButton = document.getElementById("mute");
const endCard = document.getElementById("endCard");
const countdown = document.getElementById("countdown");
const redirect = document.getElementById("redirect");

function renderMute() {
  muteButton.textContent = video.muted ? "Unmute" : "Mute";
  muteButton.setAttribute("aria-label", video.muted ? "Unmute ad" : "Mute ad");
}

async function applyMute(muted) {
  video.muted = muted;
  renderMute();
  await chrome.storage.local.set({ videoMuted: muted });
}

chrome.storage.local.get({ videoMuted: false }, async ({ videoMuted }) => {
  await applyMute(Boolean(videoMuted));
  const play = video.play();
  if (play) {
    play.catch(async () => {
      await applyMute(true);
      video.play().catch(() => {});
    });
  }
});

muteButton.addEventListener("click", () => {
  applyMute(!video.muted);
  if (video.paused) {
    video.play().catch(() => {});
  }
});

redirect.addEventListener("click", (event) => {
  event.preventDefault();
  chrome.tabs.create({ url: WHOPPER_URL });
});

video.addEventListener("ended", () => {
  endCard.hidden = false;
  let remaining = 5;
  countdown.textContent = `Closing in ${remaining}s`;
  const timer = setInterval(() => {
    remaining -= 1;
    if (remaining <= 0) {
      clearInterval(timer);
      window.close();
      return;
    }
    countdown.textContent = `Closing in ${remaining}s`;
  }, 1000);
});
