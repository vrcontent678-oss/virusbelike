const params = new URLSearchParams(location.search);
const title = params.get("title") || "Claim your prize";
const cta = params.get("cta") || "CLAIM NOW";

document.getElementById("title").textContent = title;
document.getElementById("cta").textContent = cta;

const ad = document.getElementById("ad");
const reveal = document.getElementById("reveal");

function showNotice(event) {
  event.preventDefault();
  event.stopPropagation();
  ad.hidden = true;
  reveal.hidden = false;
  document.body.classList.add("notice");
}

document.getElementById("cta").addEventListener("click", showNotice);
ad.addEventListener("click", showNotice);

document.getElementById("dismiss").addEventListener("click", () => {
  window.close();
});
